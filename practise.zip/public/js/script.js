

console.log("Your Justify Successful!!");