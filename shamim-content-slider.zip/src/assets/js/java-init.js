jQuery(document).ready(function ($) {
  $('.bxslider').bxSlider({
    mode: 'horizontal',
    pager: true,
    speed: 500,
    controls: true,
    infiniteLoop: true,
    autoControls: false
  });
});